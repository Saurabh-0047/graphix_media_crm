<!DOCTYPE html>
<html>
<?php echo $__env->make('admin.includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body>
    <?php echo $__env->make('admin.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin.includes.sidemenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="content-wrapper">
        <div class="container-full">
            <div class="content-header">
                <div class="d-flex align-items-center">
                    <div class="me-auto">
                    </div>
                </div>
            </div>
            <section class="content">
                <div class="row">
                    <div class="box">
                        <div class="box-header with-border">
                            <h4 class="box-title">Add New Project Here</h4>
                        </div>
                        <?php if(session('success')): ?>
                        <span class="text-success"><?php echo e(session('success')); ?></span>
                        <?php endif; ?>

                        <form method="POST" action="<?php echo e(route('admin.add_project.post')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="box-body">
                                <div class="form-group row">
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label class="form-label">Business Name</label>
                                            <input type="text" class="form-control" name="business_name" placeholder="Business Name..." value="<?php echo e(old('business_name')); ?>">
                                            <?php if($errors->has('business_name')): ?>
                                            <span class="text-danger"><?php echo e($errors->first('business_name')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label class="form-label">Client Name</label>
                                            <input type="text" class="form-control" name="client_name" placeholder="Client Name..." value="<?php echo e(old('client_name')); ?>">
                                            <?php if($errors->has('client_name')): ?>
                                            <span class="text-danger"><?php echo e($errors->first('client_name')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <hr>


                                    <div class="col-lg-12">
                                        <div class="form-group">
                                            <label class="form-label">Select Services:</label><br>

                                            <div class="container">
                                                <div class="row">
                                                    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="col-md-3">
                                                        <?php
                                                        // Get the previously submitted values for the checkboxes
                                                        $checkedValues = old('packages', []);
                                                        // Check if the current service should be checked
                                                        $isChecked = in_array($service->service, $checkedValues);
                                                        ?>
                                                        <input type="checkbox" id="checkbox_<?php echo e($service->id); ?>" name="packages[]" class="chk-col-primary" value="<?php echo e($service->service); ?>" <?php echo e($isChecked ? 'checked' : ''); ?> />
                                                        <label for="checkbox_<?php echo e($service->id); ?>" class="label_text"><?php echo e($service->service); ?></label>
                                                    </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                                <?php if($errors->has('packages')): ?>
                                                <span class="text-danger"><?php echo e($errors->first('packages')); ?></span>
                                                <?php endif; ?>
                                            </div>


                                        </div>
                                    </div>
                                    <hr>
                                    <div class="col-lg-12" id="modules-section">
                                        <div class="form-group">
                                            <label class="form-label">Modules</label>
                                            <div id="modules-container">
                                                <!-- Existing modules will be appended here -->
                                                <?php if(old('modules')): ?>
                                                    <?php $__currentLoopData = old('modules'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="module-item" id="module_<?php echo e($index); ?>">
                                                            <div class="form-group">
                                                                <label class="form-label">Module Heading</label>
                                                                <input type="text" class="form-control" name="modules[<?php echo e($index); ?>][heading]" value="<?php echo e($module['heading']); ?>" placeholder="Module Heading...">
                                                            </div>
                                                            <div class="form-group">
                                                                <label class="form-label">Module Description</label>
                                                                <textarea class="form-control" name="modules[<?php echo e($index); ?>][description]" placeholder="Module Description..."><?php echo e($module['description']); ?></textarea>
                                                            </div>
                                                            <button type="button" class="btn btn-danger remove-module" data-module-id="<?php echo e($index); ?>">Remove Module</button>
                                                        </div>
                                                        <hr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            </div>
                                            <button type="button" class="btn btn-primary" id="add-module">Add Module</button>
                                        </div>
                                    </div>
                                    
    <hr>                                                                        
                                    <div class="col-lg-4">
                                        <div class="form-group">
                                            <label class="form-label">Contact Number</label>
                                            <input type="text" class="form-control" name="contact_no" placeholder="Contact Number..." value="<?php echo e(old('contact_no')); ?>">
                                            <?php if($errors->has('contact_no')): ?>
                                            <span class="text-danger"><?php echo e($errors->first('contact_no')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="form-group">
                                            <label class="form-label">Email Id</label>
                                            <input type="text" class="form-control" name="email_id" placeholder="Email Id..." value="<?php echo e(old('email_id')); ?>">
                                            <?php if($errors->has('email_id')): ?>
                                            <span class="text-danger"><?php echo e($errors->first('email_id')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="form-group">
                                            <label class="form-label">Address</label>
                                            <input type="text" class="form-control" name="address" placeholder="Address..." value="<?php echo e(old('address')); ?>">
                                            <?php if($errors->has('address')): ?>
                                            <span class="text-danger"><?php echo e($errors->first('address')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label class="form-label">Website</label>
                                            <input type="text" class="form-control" name="website" placeholder="Website..." value="<?php echo e(old('website')); ?>">
                                            <?php if($errors->has('website')): ?>
                                            <span class="text-danger"><?php echo e($errors->first('website')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label class="form-label">Project Remarks</label>
                                            <textarea class="form-control" name="remarks" placeholder="Project Remarks..."><?php echo e(old('remarks')); ?></textarea>
                                            <?php if($errors->has('remarks')): ?>
                                            <span class="text-danger"><?php echo e($errors->first('remarks')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="form-group">
                                            <label class="form-label">Sold By</label>
                                            <select class="form-control" name="sold_by_id">
                                                <option value="">Select User</option>
                                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($user->id); ?>" <?php echo e(old('sold_by_id') == $user->id ? 'selected' : ''); ?>><?php echo e($user->user_name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php if($errors->has('sold_by_id')): ?>
                                            <span class="text-danger"><?php echo e($errors->first('sold_by_id')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="form-group">
                                            <label class="form-label">Assigned To</label>
                                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($user->designation_id != 8): ?>
                                            <div class="col-md-3">
                                                <?php
                                                // Get the previously submitted values for the checkboxes
                                                $assignedToValues = old('assigned_to', []);
                                                // Check if the current user should be checked
                                                $isChecked = in_array($user->id, $assignedToValues);
                                                ?>
                                                <input type="checkbox" id="assigned_<?php echo e($user->id); ?>" name="assigned_to[]" class="chk-col-primary" value="<?php echo e($user->id); ?>" <?php echo e($isChecked ? 'checked' : ''); ?> />
                                                <label for="assigned_<?php echo e($user->id); ?>" class="label_text"><?php echo e($user->user_name); ?></label>
                                            </div>
                                            <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($errors->has('assigned_to')): ?>
                                            <span class="text-danger"><?php echo e($errors->first('assigned_to')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>

                                </div>
                            </div>
                    </div>
                    <div class="box-footer">
                        <button type="submit" class="btn btn-danger">Cancel</button>
                        <input type="submit" name="sub" class="btn btn-info pull-right" value="Submit">
                    </div>
                    </form>
                </div>
        </div>
        </section>
    </div>
    </div>
    <?php echo $__env->make('admin.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin.includes.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script>
        $(document).ready(function() {
            let moduleIndex = $('.module-item').length > 0 ? $('.module-item').length : 0;
    
            $('#add-module').click(function() {
                moduleIndex++;
                const moduleHtml = `
                    <div class="module-item" id="module_${moduleIndex}">
                        <div class="form-group">
                            <label class="form-label">Module Heading</label>
                            <input type="text" class="form-control" name="modules[${moduleIndex}][heading]" placeholder="Module Heading...">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Module Description</label>
                            <textarea class="form-control" name="modules[${moduleIndex}][description]" placeholder="Module Description..."></textarea>
                        </div>
                        <button type="button" class="btn btn-danger remove-module" data-module-id="${moduleIndex}">Remove Module</button>
                    </div>
                    <hr>
                `;
                $('#modules-container').append(moduleHtml);
            });
    
            $('#modules-container').on('click', '.remove-module', function() {
                const moduleId = $(this).data('module-id');
                $(`#module_${moduleId}`).remove();
            });
        });
    </script>
    
</body>

</html><?php /**PATH C:\xampp\htdocs\graphix_media_crm\resources\views/admin/add_projects.blade.php ENDPATH**/ ?>