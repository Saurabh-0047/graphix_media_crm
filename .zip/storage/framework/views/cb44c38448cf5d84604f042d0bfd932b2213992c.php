<!DOCTYPE html>
<html>
<?php echo $__env->make('admin.includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body>
    <?php echo $__env->make('admin.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin.includes.sidemenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="content-wrapper">
        <div class="container-full">
            <div class="content-header">
                <div class="d-flex align-items-center">
                    <div class="me-auto">
                    </div>
                </div>
            </div>
            <section class="content">
                <div class="row">
                    <div class="box">
                        <div class="box-header with-border">
                            <h4 class="box-title">Enter Users Here</h4>
                        </div>
                        <?php if(session('success')): ?>
                        <span class="text-success"><?php echo e(session('success')); ?></span>
                        <?php endif; ?>
                        <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <?php endif; ?>

                        <form method="POST" action="<?php echo e(route('user.store')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="box-body">
                                <div class="form-group row">
                                    <div class="col-lg-4">
                                        <div class="form-group">
                                            <label class="form-label">Designation</label>
                                            <select class="form-control" name="designation_id">
                                                <option value="">Select Designation</option>
                                                <?php $__currentLoopData = $designations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $designation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($designation->id); ?>" <?php echo e(old('designation_id') == $designation->id ? 'selected' : ''); ?>>
                                                    <?php echo e($designation->designation); ?>

                                                </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="col-lg-4">
                                        <div class="form-group">
                                            <label class="form-label">User Name</label>
                                            <input type="text" name="user_name" id="user_name" class="form-control" placeholder="User Name" value="<?php echo e(old('user_name')); ?>">
                                        </div>
                                    </div>

                                    <div class="col-lg-4">
                                        <div class="form-group">
                                            <label class="form-label">User Id</label>
                                            <input type="text" name="user_id" id="user_id" class="form-control" placeholder="User Id" value="<?php echo e(old('user_id')); ?>">
                                        </div>
                                    </div>

                                    <div class="col-lg-4">
                                        <div class="form-group">
                                            <label class="form-label">User Phone</label>
                                            <input type="text" name="user_phone" id="user_phone" class="form-control" placeholder="User Phone" value="<?php echo e(old('user_phone')); ?>">
                                        </div>
                                    </div>

                                    <div class="col-lg-4">
                                        <div class="form-group">
                                            <label class="form-label">User Email</label>
                                            <input type="text" name="user_email" id="user_email" class="form-control" placeholder="User Email" value="<?php echo e(old('user_email')); ?>">
                                        </div>
                                    </div>

                                    <div class="col-lg-4">
                                        <div class="form-group">
                                            <label class="form-label">Password</label>
                                            <input type="password" name="password" id="password" class="form-control" placeholder="User Password">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="box-footer">
                                <a href="<?php echo e(route('admin.users')); ?>" class="btn btn-danger">Cancel</a>
                                <input type="submit" class="btn btn-info pull-right" value="Submit">
                            </div>
                        </form>

                    </div>
                    <div class="box">
                        <div class="box-header with-border">
                            <h4 class="box-title">All Users</h4>
                        </div>


                        <div class="table-responsive">
                            <table id="example" class="table text-fade table-bordered table-hover display nowrap margin-top-10 w-p100">
                                <thead>
                                    <tr class="text-dark">
                                        <th>S.NO</th>
                                        <th>Designation</th>
                                        <th>User Name</th>
                                        <th>User Id</th>
                                        <th>Email</th>
                                        <th>Mobile</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $i = 1; ?>
                                    <?php $__currentLoopData = $user_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $users): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($i); ?></td>
                                        <td><?php echo e($users->designation->designation ?? 'N/A'); ?></td>
                                        <td><?php echo e($users->user_name); ?></td>
                                        <td><?php echo e($users->user_id); ?></td>
                                        <td><?php echo e($users->user_email); ?></td>
                                        <td><?php echo e($users->user_phone); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('admin.users.edit', $users->id)); ?>" class="btn btn-primary btn-sm">
                                                <i class="fas fa-edit"></i>
                                            </a>&nbsp;&nbsp;&nbsp;
                                            <a href="<?php echo e(route('admin.users.toggleStatus', $users->id)); ?>" class="btn <?php echo e($users->status == 1 ? 'btn-warning' : 'btn-success'); ?> btn-sm">
                                                <i class="fas <?php echo e($users->status == 1 ? 'fa-toggle-off' : 'fa-toggle-on'); ?>"></i>
                                                <?php echo e($users->status == 1 ? 'Deactivate' : 'Activate'); ?>

                                            </a>


                                        </td>


                                    </tr>
                                    <?php $i++; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
    <?php echo $__env->make('admin.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin.includes.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html><?php /**PATH C:\New Xampp\htdocs\graphix_media_crm\resources\views/admin/users.blade.php ENDPATH**/ ?>