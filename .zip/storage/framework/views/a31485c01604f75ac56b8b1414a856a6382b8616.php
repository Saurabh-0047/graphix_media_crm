<aside class="main-sidebar">
    <section class="sidebar position-relative"> 
        <div class="multinav">
            <div class="multinav-scroll" style="height: 97%;">    
                <ul class="sidebar-menu" data-widget="tree">
                    <li><a href="<?php echo e(url('admin/dashboard')); ?>"><i class="icon-Commit"><span class="path1"></span><span class="path2"></span></i>Dashboard</a></li>

                    <li class="treeview">
                        <a href="#">
                            <i data-feather="grid"></i>
                            <span>Users</span>
                            <span class="pull-right-container">
                                <i class="fa fa-angle-right pull-right"></i>
                            </span>
                        </a>          
                        <ul class="treeview-menu">          
                        <li><a href="<?php echo e(url('admin/user_designation')); ?>"><i class="icon-Commit"><span class="path1"></span><span class="path2"></span></i>Designations</a></li>    
                        <li><a href="<?php echo e(url('admin/users')); ?>"><i class="icon-Commit"><span class="path1"></span><span class="path2"></span></i>Users</a></li>
                            <li><a href="<?php echo e(url('admin/table')); ?>"><i class="icon-Commit"><span class="path1"></span><span class="path2"></span></i>Table</a></li>
                        </ul>
                    </li> 

                    <li class="treeview">
                        <a href="#">
                            <i data-feather="grid"></i>
                            <span>Projects</span>
                            <span class="pull-right-container">
                                <i class="fa fa-angle-right pull-right"></i>
                            </span>
                        </a>          
                        <ul class="treeview-menu">          
                        <li><a href="<?php echo e(url('admin/project_services')); ?>"><i class="icon-Commit"><span class="path1"></span><span class="path2"></span></i>All Services</a></li>

                        <li><a href="<?php echo e(url('admin/add_projects')); ?>"><i class="icon-Commit"><span class="path1"></span><span class="path2"></span></i>Add Projects</a></li>
                        <li><a href="<?php echo e(url('admin/projects')); ?>"><i class="icon-Commit"><span class="path1"></span><span class="path2"></span></i>All Projects</a></li>    
                        <li><a href="<?php echo e(url('admin/users')); ?>"><i class="icon-Commit"><span class="path1"></span><span class="path2"></span></i>Users</a></li>
                            <li><a href="<?php echo e(url('admin/table')); ?>"><i class="icon-Commit"><span class="path1"></span><span class="path2"></span></i>Table</a></li>
                        </ul>
                    </li> 
                    <li>
                        <a href="<?php echo e(route('logout')); ?>"
                           onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                            <i class="icon-Commit"><span class="path1"></span><span class="path2"></span></i>Logout
                        </a>

                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="GET" style="display: none;">
                            <?php echo csrf_field(); ?>
                        </form>
                    </li>
                </ul>
            </div>
        </div>
    </section>
</aside>
<?php /**PATH C:\New Xampp\htdocs\graphix_media_crm\resources\views/admin/includes/sidemenu.blade.php ENDPATH**/ ?>