<script src="<?php echo e(asset('src/js/vendors.min.js')); ?>"></script>
<script src="<?php echo e(asset('src/js/pages/chat-popup.js')); ?>"></script>
<script src="<?php echo e(asset('assets/icons/feather-icons/feather.min.js')); ?>"></script>  
<script src="<?php echo e(asset('assets/vendor_components/jquery-steps-master/build/jquery.steps.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor_components/jquery-validation-1.17.0/dist/jquery.validate.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor_components/sweetalert/sweetalert.min.js')); ?>"></script>
<script src="<?php echo e(asset('src/js/pages/data-table.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor_components/datatable/datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('src/js/demo.js')); ?>"></script>
<script src="<?php echo e(asset('src/js/template.js')); ?>"></script>
<script src="<?php echo e(asset('src/js/pages/steps.js')); ?>"></script>
<?php /**PATH C:\New Xampp\htdocs\graphix_media_crm\resources\views/user/includes/js.blade.php ENDPATH**/ ?>