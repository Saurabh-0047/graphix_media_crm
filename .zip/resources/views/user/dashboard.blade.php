<!DOCTYPE html>
<html lang="en">
<head>
    @include('user.includes.head')
</head>
<body>
    @include('user.includes.header')
    @include('user.includes.sidemenu')
    <div class="content-wrapper">
        <div class="container-full">
            <div class="content-header">
                <div class="d-flex align-items-center">
                    <div class="me-auto">
                    </div>
                </div>
            </div>
            <section class="content">
                <div class="row">
                   
                </div>
            </section>
        </div>
    </div>
    @include('user.includes.footer')
    @include('user.includes.js')
</body>
</html>
