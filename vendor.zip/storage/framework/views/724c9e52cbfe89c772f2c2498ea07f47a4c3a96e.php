<!DOCTYPE html>
<html>
<?php echo $__env->make('admin.includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body>
    <?php echo $__env->make('admin.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin.includes.sidemenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="content-wrapper">
        <div class="container-full">
            <div class="content-header">
                <div class="d-flex align-items-center">
                    <div class="me-auto">
                    </div>
                </div>
            </div>
            <section class="content">
                <div class="row">

                    <div class="box">
                        <div class="box-header with-border">
                            <h4 class="box-title">All Projects</h4>
                        </div>

                        <div class="table-responsive">
                            <table id="example" class="table text-fade table-bordered table-hover display nowrap margin-top-10 w-p100">
                                <thead>
                                    <tr class="text-dark">
                                        <th>S.NO</th>
                                        <th>Details</th>
                                        <th>Business Name</th>
                                        <th>Assigned To</th>
                                        <th>Client Name</th>
                                        <th>Contact Number</th>
                                        <th>Email Id</th>
                                        <th>Address</th>
                                        <th>Website</th>
                                        <th>Packages</th>
                                        <th>Sold By</th>
                                        <th>Added On</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $i = 1; ?>
                                    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($i); ?></td>
                                        <td><a href="<?php echo e(route('admin.project_details', $project->id)); ?>" class="btn btn-primary btn-sm">
                                                <i class="fas fa-eye"></i>
                                            </a></td>
                                        <td><?php echo e($project->business_name); ?></td>
                                        <td>
                                            <?php $__currentLoopData = $project->assigned_users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <span><?php echo e($user->user_name); ?></span>
                                            <?php if(!$loop->last): ?>
                                            ,
                                            <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </td>


                                        <td><?php echo e($project->client_name); ?></td>
                                        <td><?php echo e($project->contact_no); ?></td>
                                        <td><?php echo e($project->email_id); ?></td>
                                        <td><?php echo e($project->address); ?></td>
                                        <td><?php echo e($project->website); ?></td>
                                        <td><?php echo e($project->packages); ?></td>
                                        <td><?php echo e($project->user->user_name ?? 'N/A'); ?></td>
                                        <td><?php echo e($project->created_at); ?></td>
                                        
                                       

                                    </tr>
                                    <?php $i++; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
    <?php echo $__env->make('admin.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin.includes.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html><?php /**PATH C:\New Xampp\htdocs\graphix_media_crm\resources\views/admin/projects.blade.php ENDPATH**/ ?>