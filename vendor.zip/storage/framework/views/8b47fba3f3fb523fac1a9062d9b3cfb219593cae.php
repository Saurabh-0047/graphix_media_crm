<!DOCTYPE html>
<html>
<?php echo $__env->make('admin.includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body>
    <?php echo $__env->make('admin.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin.includes.sidemenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="content-wrapper">
        <div class="container-full">
            <div class="content-header">
                <div class="d-flex align-items-center">
                    <div class="me-auto">
                    </div>
                </div>
            </div>
            <section class="content">
                <div class="row">
                    <div class="box">
                        <div class="box-header with-border">
                            <h4 class="box-title">Enter Service Here</h4>
                        </div>
                        <?php if(session('success')): ?>
                        <span class="text-success"><?php echo e(session('success')); ?></span>
                        <?php endif; ?>

                        <form method="POST" action="<?php echo e(route('admin.project_services.post')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="box-body">
                                <div class="form-group row">
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label class="form-label">Service</label>
                                            <input type="text" class="form-control" name="service" placeholder="Service...">
                                            <?php if($errors->has('service')): ?>
                                            <span class="text-danger"><?php echo e($errors->first('service')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="box-footer">
                                <button type="submit" class="btn btn-danger">Cancel</button>
                                <input type="submit" name="sub" class="btn btn-info pull-right" value="Submit">
                            </div>
                        </form>
                    </div>
                    <div class="box">
                        <div class="box-header with-border">
                            <h4 class="box-title">All services</h4>
                        </div>
                        <div class="table-responsive">
                            <table id="example" class="table text-fade table-bordered table-hover display nowrap margin-top-10 w-p100">
                                <thead>
                                    <tr class="text-dark">
                                        <th>S.NO</th>
                                        <th>Service</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $i = 1; ?>
                                    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($i); ?></td>
                                        <td><?php echo e($service->service); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('admin.project_services.edit', $service->id)); ?>" class="btn btn-primary btn-sm">
                                                <i class="fas fa-edit"></i>
                                            </a>&nbsp;&nbsp;&nbsp;
                                            <a href="<?php echo e(route('admin.project_services.toggleStatus', $service->id)); ?>" class="btn <?php echo e($service->status == 1 ? 'btn-danger' : 'btn-success'); ?> btn-sm">
                                                <i class="fas <?php echo e($service->status == 1 ? 'fa-toggle-off' : 'fa-toggle-on'); ?>"></i>
                                                <?php echo e($service->status == 1 ? 'Deactivate' : 'Activate'); ?>

                                            </a>
                                        </td>
                                    </tr>
                                    <?php $i++; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>

                    </div>
                </div>
            </section>
        </div>
    </div>
    <?php echo $__env->make('admin.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin.includes.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html><?php /**PATH C:\New Xampp\htdocs\graphix_media_crm\resources\views/admin/project_services.blade.php ENDPATH**/ ?>